# Build on Android using GitHub Actions

1. Sign in to GitHub in your Android browser.
2. Create a new public or private repository.
3. Upload the contents of this project (including the hidden `.github` folder).
4. Open the repository's **Actions** tab.
5. Select **Build Fabric Mod**, then **Run workflow** if it has not started automatically.
6. Open the completed run and download the artifact named `achievement-hunter-fabric-1.21`.
7. Extract the downloaded artifact and copy its `.jar` into `.minecraft/mods/` in Fold Craft Launcher.
8. Make sure Fabric API for Minecraft 1.21 is also installed.

This workflow compiles the source in GitHub's hosted environment; it does not require Gradle or Java to be installed on the Android phone.

Important: This is a build workflow, not a guarantee that the source has already been tested in-game. If the build fails, open the failed job log and share the error text so the source can be corrected.
