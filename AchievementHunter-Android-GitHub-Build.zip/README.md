# Achievement Hunter — Fabric 1.21

A small Fabric mod for Minecraft Java Edition 1.21.

## Reward
Every time the player unlocks an advancement OR personally kills a mob:
- +3 attack damage
- +2 maximum health (one heart)
- +1 hunger point
- +25% block-breaking speed

Rewards stack and the stack count is saved in the player's NBT data, so it survives relogging and normal death/respawn player-data copying.

## Build
Requirements: JDK 21 and Gradle 8.x.

Run:
```bash
gradle build
```
The built mod jar will be in `build/libs/`.

## Install
Put the built `achievement-hunter-1.0.0.jar` in the `mods` folder of a Minecraft 1.21 Fabric installation, together with Fabric API.

## Notes
- Advancement rewards trigger once for each advancement unlock.
- Mob rewards trigger when a `MobEntity` dies and the direct damage-source attacker is the player.
- The mining bonus is intentionally uncapped, matching the requested stacking rule.
- This is a source project; build it locally with JDK 21 to produce the game-ready JAR.
