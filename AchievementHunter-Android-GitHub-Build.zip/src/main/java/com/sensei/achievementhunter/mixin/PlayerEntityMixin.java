package com.sensei.achievementhunter.mixin;

import com.sensei.achievementhunter.RewardData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.block.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin implements RewardData {
    @Unique
    private int achievementHunter$rewards = 0;

    @Override
    public int achievementHunter$getRewards() {
        return achievementHunter$rewards;
    }

    @Override
    public void achievementHunter$addReward() {
        achievementHunter$rewards++;
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void achievementHunter$writeData(NbtCompound nbt, CallbackInfo ci) {
        nbt.putInt("AchievementHunterRewards", achievementHunter$rewards);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void achievementHunter$readData(NbtCompound nbt, CallbackInfo ci) {
        achievementHunter$rewards = Math.max(0, nbt.getInt("AchievementHunterRewards"));
    }

    @Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true)
    private void achievementHunter$boostMiningSpeed(BlockState state,
            CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(cir.getReturnValue() * (1.0F + 0.25F * achievementHunter$rewards));
    }
}
