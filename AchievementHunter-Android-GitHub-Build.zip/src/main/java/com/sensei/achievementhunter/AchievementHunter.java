package com.sensei.achievementhunter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.PlayerAdvancementEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class AchievementHunter implements ModInitializer {
    private static final Identifier DAMAGE_ID = Identifier.of("achievement_hunter", "stacking_damage");
    private static final Identifier HEALTH_ID = Identifier.of("achievement_hunter", "stacking_health");

    @Override
    public void onInitialize() {
        PlayerAdvancementEvents.AFTER.register((player, advancement) -> {
            if (player instanceof ServerPlayerEntity serverPlayer) {
                grantReward(serverPlayer);
            }
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof MobEntity)) return;
            Entity attacker = damageSource.getAttacker();
            if (attacker instanceof ServerPlayerEntity player) {
                grantReward(player);
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                refreshAttributes(handler.player));
    }

    private static void grantReward(ServerPlayerEntity player) {
        RewardData data = (RewardData) player;
        data.achievementHunter$addReward();

        int stacks = data.achievementHunter$getRewards();
        refreshAttributes(player);

        // Restore one hunger point per reward; saturation is left unchanged.
        player.getHungerManager().add(1, 0.0F);
    }

    private static void refreshAttributes(ServerPlayerEntity player) {
        int stacks = ((RewardData) player).achievementHunter$getRewards();

        EntityAttributeInstance damage = player.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (damage != null) {
            damage.removeModifier(DAMAGE_ID);
            if (stacks > 0) {
                damage.addPersistentModifier(new EntityAttributeModifier(
                        DAMAGE_ID, 3.0D * stacks, EntityAttributeModifier.Operation.ADD_VALUE));
            }
        }

        EntityAttributeInstance health = player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        if (health != null) {
            health.removeModifier(HEALTH_ID);
            if (stacks > 0) {
                health.addPersistentModifier(new EntityAttributeModifier(
                        HEALTH_ID, 2.0D * stacks, EntityAttributeModifier.Operation.ADD_VALUE));
            }
            // Keep current health valid after the maximum-health attribute is restored.
            player.setHealth(Math.min(player.getHealth(), player.getMaxHealth()));
        }
    }
}
