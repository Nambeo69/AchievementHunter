package com.sensei.achievementhunter;

public interface RewardData {
    int achievementHunter$getRewards();
    void achievementHunter$addReward();
}
